var firebaseConfig = {
    apiKey: "AIzaSyCFMBZG17ZdoH9W7gpaq11GBgGluWC3CyU",
    authDomain: "study-mobile-f9a91.firebaseapp.com",
    databaseURL: "https://study-mobile-f9a91.firebaseio.com",
    projectId: "study-mobile-f9a91",
    storageBucket: "study-mobile-f9a91.appspot.com",
    messagingSenderId: "1087807604379",
    appId: "1:1087807604379:web:209ca946ef56ee0a51683e",
    measurementId: "G-8H2B89ZDC3"
  };