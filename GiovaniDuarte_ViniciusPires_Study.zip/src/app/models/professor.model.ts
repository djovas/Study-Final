export interface Professor {
    id: String,
    nome: String,
    materia: String,
    descricao: String,
    telefone: String,
    horario: String
    // foto: string,
}